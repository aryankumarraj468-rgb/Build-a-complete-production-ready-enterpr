# Architecture

```
Client ─► Ingress (TLS, rate limit) ─► Service ─► Pods (3+, HPA) ─► Store interface ─► (in-memory | PostgreSQL)
                                                     │
                                                     └─► /metrics ◄── Prometheus ◄── Grafana / Alertmanager
```

Layers (`src/`): `server.js` (process lifecycle) → `app.js` (routing, middleware, handlers) →
`validate.js` / `auth.js` / `ratelimit.js` (policies) → `store.js` (persistence port).
All dependencies are injected into `createApp`, so tests run the real HTTP stack on an ephemeral port.

## Architecture decision records

**ADR-001 — Zero runtime dependencies.** Node built-ins cover HTTP, crypto and testing. Trade-off: we maintain a small
router and metrics registry ourselves; benefit: no transitive CVEs, faster builds, tiny image. Revisit if routing needs grow.

**ADR-002 — Repository port with in-memory adapter.** Business logic depends on an async store interface. A PostgreSQL
adapter (e.g. `pg`) can be added without touching handlers. Reference implementation keeps the demo self-contained.

**ADR-003 — Stateless auth with short-lived JWT (HS256).** Enables horizontal scaling. Trade-off: no server-side revocation;
mitigated by a 1h TTL. For multi-service setups move to asymmetric keys (RS256/EdDSA) and an IdP.

**ADR-004 — Kustomize overlays over Helm.** Plain YAML is reviewable and schema-validatable in CI; overlays cover the
staging/production differences (replicas, host, PDB).

**ADR-005 — Promotion by immutable tag.** The same image digest built in CI is promoted staging → production; nothing is rebuilt.

## Security model

- AuthN: bearer JWT; AuthZ: role + ownership checks; cross-tenant access returns 404.
- Passwords: scrypt with random 16-byte salt; login timing equalised for unknown users.
- Transport: TLS terminated at ingress. `/metrics` blocked at ingress and optionally token protected.
- Runtime: non-root, read-only root FS, all capabilities dropped, seccomp RuntimeDefault, NetworkPolicy, restricted Pod Security.
- Supply chain: pinned base image, Trivy, CodeQL, gitleaks, SBOM + SLSA provenance, attestation verified before prod deploy.

## SLOs (alerts in `monitoring/alerts.yml`)

| SLI | Objective |
|---|---|
| Availability (non-5xx) | 99.9% / 30 days |
| Latency p95 | < 500 ms |
