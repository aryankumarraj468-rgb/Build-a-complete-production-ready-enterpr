# Runbook

Useful commands: `kubectl -n taskflow-prod get pods`, `kubectl -n taskflow-prod logs deploy/taskflow-api --tail=200`,
`kubectl -n taskflow-prod rollout history deploy/taskflow-api`.

## Rollback
`kubectl -n taskflow-prod rollout undo deploy/taskflow-api` (the CD pipeline does this automatically when a smoke test fails).

## High error rate
1. Check Grafana "Error rate" and filter logs for `"level":"error"` (every line carries `requestId`).
2. Did a deploy happen in the last 30 min? If so, roll back first, investigate second.
3. Check pod restarts / OOMKills: `kubectl describe pod`. Raise memory limits only after finding the cause.

## High latency
1. Compare p95 per route (`http_request_duration_seconds_bucket` by `route`).
2. Check HPA saturation: `kubectl get hpa`. Raise `maxReplicas` if pinned at max with high CPU.
3. Look for large page sizes or a flood of auth requests (scrypt is deliberately CPU-expensive).

## Instance down
`kubectl get pods`; look at `Events` for image pull, probe or scheduling failures. The PDB keeps ≥ 2 pods during node drains.

## Login failure spike
Likely credential stuffing. Confirm via `login_failures_total` and ingress logs; tighten `nginx.ingress.kubernetes.io/limit-rps`
or `AUTH_RATE_LIMIT_MAX`, and block offending CIDRs at the edge.

## Rotating the JWT secret
Update `taskflow-secrets`, then `kubectl rollout restart deploy/taskflow-api`. All existing tokens become invalid (users re-login).
