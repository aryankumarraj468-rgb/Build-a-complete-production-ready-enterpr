'use strict';

const http = require('node:http');
const { loadConfig } = require('../src/config');
const { createLogger } = require('../src/logger');
const { createMetrics } = require('../src/metrics');
const { createMemoryStore } = require('../src/store');
const { createApp } = require('../src/app');

async function startServer(envOverrides = {}) {
  const config = loadConfig({ NODE_ENV: 'test', ...envOverrides });
  const store = createMemoryStore();
  const metrics = createMetrics();
  const app = createApp({ config, store, logger: createLogger('silent'), metrics });
  const server = http.createServer(app.handler);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;

  const call = async (method, path, { body, token, headers } = {}) => {
    const res = await fetch(base + path, {
      method,
      headers: { ...(body !== undefined ? { 'content-type': 'application/json' } : {}), ...(token ? { authorization: `Bearer ${token}` } : {}), ...headers },
      body: body !== undefined ? (typeof body === 'string' ? body : JSON.stringify(body)) : undefined,
    });
    const text = await res.text();
    let json;
    try { json = JSON.parse(text); } catch { json = undefined; }
    return { status: res.status, headers: res.headers, json, text };
  };

  const register = async (email, password = 'correct-horse-battery') => {
    await call('POST', '/auth/register', { body: { email, password } });
    const r = await call('POST', '/auth/login', { body: { email, password } });
    return r.json.token;
  };

  return { base, call, register, store, app, config, close: () => new Promise((r) => { server.closeAllConnections(); server.close(r); }) };
}

module.exports = { startServer };
