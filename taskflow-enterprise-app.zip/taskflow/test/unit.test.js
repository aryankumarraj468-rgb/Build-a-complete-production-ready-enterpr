'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { hashPassword, verifyPassword, signJwt, verifyJwt } = require('../src/auth');
const { createRateLimiter } = require('../src/ratelimit');
const { validateTask, validateCredentials, validatePagination } = require('../src/validate');
const { loadConfig } = require('../src/config');
const { createMetrics } = require('../src/metrics');
const { createLogger } = require('../src/logger');

test('password hashing verifies correct and rejects wrong passwords', () => {
  const h = hashPassword('s3cret-passphrase');
  assert.ok(verifyPassword('s3cret-passphrase', h));
  assert.ok(!verifyPassword('wrong', h));
  assert.notEqual(h, hashPassword('s3cret-passphrase'), 'salts must differ');
  assert.ok(!verifyPassword('x', 'garbage'));
});

test('JWT round-trip, tamper and expiry detection', () => {
  const t = signJwt({ sub: 'u1' }, 'secret', 60, 1_000_000);
  assert.equal(verifyJwt(t, 'secret', 1_000_000).sub, 'u1');
  assert.throws(() => verifyJwt(t, 'other', 1_000_000), { code: 'invalid_token' });
  assert.throws(() => verifyJwt(t, 'secret', 1_000_000 + 61_000), { code: 'token_expired' });
  assert.throws(() => verifyJwt('a.b', 'secret'), { code: 'invalid_token' });
  assert.throws(() => verifyJwt('a.b.c', 'secret'), { code: 'invalid_token' });
  const none = `${Buffer.from('{"alg":"none"}').toString('base64url')}.${Buffer.from('{}').toString('base64url')}.`;
  assert.throws(() => verifyJwt(none, 'secret'), { code: 'invalid_token' });
});

test('rate limiter blocks after max and resets after window', () => {
  let now = 0;
  const rl = createRateLimiter({ windowMs: 1000, max: 2 }, () => now);
  assert.ok(rl.check('k').allowed);
  assert.ok(rl.check('k').allowed);
  assert.ok(!rl.check('k').allowed);
  assert.ok(rl.check('other').allowed);
  now = 1001;
  assert.ok(rl.check('k').allowed);
});

test('task validation accepts valid and rejects invalid input', () => {
  assert.deepEqual(validateTask({ title: '  Ship it ' }, { partial: false }), { title: 'Ship it' });
  assert.throws(() => validateTask({}, { partial: false }), { code: 'validation_error' });
  assert.throws(() => validateTask({ title: 'x', status: 'bogus' }, { partial: true }), { code: 'validation_error' });
  assert.throws(() => validateTask({ dueDate: 'not-a-date' }, { partial: true }), { code: 'validation_error' });
  assert.throws(() => validateTask([], { partial: true }), { code: 'validation_error' });
  assert.deepEqual(validateTask({ status: 'done' }, { partial: true }), { status: 'done' });
});

test('credential and pagination validation', () => {
  assert.deepEqual(validateCredentials({ email: 'A@B.io', password: 'longenoughpw' }, { strictPassword: true }), { email: 'a@b.io', password: 'longenoughpw' });
  assert.throws(() => validateCredentials({ email: 'bad', password: 'x' }, { strictPassword: true }), { code: 'validation_error' });
  assert.throws(() => validatePagination(new URLSearchParams('limit=0')), { code: 'validation_error' });
  assert.throws(() => validatePagination(new URLSearchParams('offset=-1')), { code: 'validation_error' });
  assert.deepEqual(validatePagination(new URLSearchParams('limit=5&status=done')), { limit: 5, offset: 0, status: 'done' });
});

test('config enforces production secret rules', () => {
  assert.throws(() => loadConfig({ NODE_ENV: 'production' }), /JWT_SECRET is required/);
  assert.throws(() => loadConfig({ NODE_ENV: 'production', JWT_SECRET: 'short' }), /at least 32/);
  assert.equal(loadConfig({ NODE_ENV: 'production', JWT_SECRET: 'x'.repeat(32), PORT: '8080' }).port, 8080);
});

test('metrics render Prometheus text format', () => {
  const m = createMetrics();
  m.inc('hits_total', { route: '/a' });
  m.observe('lat_seconds', { route: '/a' }, 0.03);
  m.gauge('thing', () => 7);
  const out = m.render();
  assert.match(out, /hits_total\{route="\/a"\} 1/);
  assert.match(out, /lat_seconds_bucket\{route="\/a",le="0.05"\} 1/);
  assert.match(out, /lat_seconds_count\{route="\/a"\} 1/);
  assert.match(out, /^thing 7$/m);
});

test('logger emits JSON and respects level', () => {
  const lines = [];
  const log = createLogger('warn', { svc: 'x' }, { write: (s) => lines.push(s) });
  log.info('hidden');
  log.child({ a: 1 }).error('shown', { b: 2 });
  assert.equal(lines.length, 1);
  assert.deepEqual(JSON.parse(lines[0]), { ...JSON.parse(lines[0]), level: 'error', msg: 'shown', svc: 'x', a: 1, b: 2 });
});
