'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { startServer } = require('./helpers');

test('health, version and security headers', async (t) => {
  const s = await startServer();
  t.after(s.close);
  assert.equal((await s.call('GET', '/health/live')).status, 200);
  assert.equal((await s.call('GET', '/health/ready')).status, 200);
  const v = await s.call('GET', '/version');
  assert.equal(v.json.env, 'test');
  assert.equal(v.headers.get('x-content-type-options'), 'nosniff');
  assert.ok(v.headers.get('x-request-id'));
  const echoed = await s.call('GET', '/version', { headers: { 'x-request-id': 'trace-12345678' } });
  assert.equal(echoed.headers.get('x-request-id'), 'trace-12345678');
});

test('readiness fails while draining', async (t) => {
  const s = await startServer();
  t.after(s.close);
  s.app.setDraining(true);
  assert.equal((await s.call('GET', '/health/ready')).status, 503);
});

test('registration and login flow', async (t) => {
  const s = await startServer();
  t.after(s.close);
  const body = { email: 'Alice@Example.com', password: 'correct-horse-battery' };
  const reg = await s.call('POST', '/auth/register', { body });
  assert.equal(reg.status, 201);
  assert.equal(reg.json.email, 'alice@example.com');
  assert.equal(reg.json.passwordHash, undefined, 'hash must never be exposed');
  assert.equal((await s.call('POST', '/auth/register', { body })).status, 409);
  assert.equal((await s.call('POST', '/auth/register', { body: { email: 'b@b.io', password: 'short' } })).status, 400);
  const login = await s.call('POST', '/auth/login', { body });
  assert.equal(login.status, 200);
  assert.ok(login.json.token);
  assert.equal((await s.call('POST', '/auth/login', { body: { ...body, password: 'wrong-password' } })).status, 401);
  assert.equal((await s.call('POST', '/auth/login', { body: { email: 'nobody@x.io', password: 'whatever' } })).status, 401);
});

test('auth is enforced on task routes', async (t) => {
  const s = await startServer();
  t.after(s.close);
  assert.equal((await s.call('GET', '/tasks')).status, 401);
  assert.equal((await s.call('GET', '/tasks', { token: 'bad.token.here' })).status, 401);
});

test('task CRUD lifecycle with filtering and pagination', async (t) => {
  const s = await startServer();
  t.after(s.close);
  const token = await s.register('crud@example.com');

  const created = await s.call('POST', '/tasks', { token, body: { title: 'Write tests', priority: 'high' } });
  assert.equal(created.status, 201);
  assert.equal(created.json.status, 'todo');
  const id = created.json.id;

  assert.equal((await s.call('GET', `/tasks/${id}`, { token })).json.title, 'Write tests');
  const upd = await s.call('PUT', `/tasks/${id}`, { token, body: { status: 'done' } });
  assert.equal(upd.json.status, 'done');
  assert.equal(upd.json.title, 'Write tests');

  for (let i = 0; i < 3; i++) await s.call('POST', '/tasks', { token, body: { title: `t${i}` } });
  const page = await s.call('GET', '/tasks?limit=2&offset=0', { token });
  assert.equal(page.json.total, 4);
  assert.equal(page.json.items.length, 2);
  assert.equal((await s.call('GET', '/tasks?status=done', { token })).json.total, 1);
  assert.equal((await s.call('GET', '/tasks?limit=1000', { token })).status, 400);

  assert.equal((await s.call('DELETE', `/tasks/${id}`, { token })).status, 204);
  assert.equal((await s.call('GET', `/tasks/${id}`, { token })).status, 404);
});

test('tenant isolation: users cannot see or modify each other\'s tasks; admins can', async (t) => {
  const s = await startServer();
  t.after(s.close);
  const alice = await s.register('alice@example.com');
  const bob = await s.register('bob@example.com');
  const { json: task } = await s.call('POST', '/tasks', { token: alice, body: { title: 'private' } });

  assert.equal((await s.call('GET', `/tasks/${task.id}`, { token: bob })).status, 404);
  assert.equal((await s.call('PUT', `/tasks/${task.id}`, { token: bob, body: { title: 'x' } })).status, 404);
  assert.equal((await s.call('DELETE', `/tasks/${task.id}`, { token: bob })).status, 404);
  assert.equal((await s.call('GET', '/tasks', { token: bob })).json.total, 0);

  await s.store.createUser({ email: 'admin@example.com', passwordHash: require('../src/auth').hashPassword('admin-password-123'), role: 'admin' });
  const adminToken = (await s.call('POST', '/auth/login', { body: { email: 'admin@example.com', password: 'admin-password-123' } })).json.token;
  assert.equal((await s.call('GET', '/tasks', { token: adminToken })).json.total, 1);
  assert.equal((await s.call('GET', `/tasks/${task.id}`, { token: adminToken })).status, 200);
});

test('input hardening: bad JSON, wrong content type, oversized body, unknown route', async (t) => {
  const s = await startServer({ MAX_BODY_BYTES: '200' });
  t.after(s.close);
  const token = await s.register('hard@example.com');
  assert.equal((await s.call('POST', '/tasks', { token, body: '{bad json', headers: {} })).json.error.code, 'invalid_json');
  const wrongType = await fetch(`${s.base}/tasks`, { method: 'POST', headers: { authorization: `Bearer ${token}`, 'content-type': 'text/plain' }, body: 'hi' });
  assert.equal(wrongType.status, 415);
  assert.equal((await s.call('POST', '/tasks', { token, body: { title: 'x'.repeat(500) } })).status, 413);
  const nf = await s.call('GET', '/nope');
  assert.equal(nf.status, 404);
  assert.ok(nf.json.error.requestId);
});

test('auth endpoints are rate limited', async (t) => {
  const s = await startServer({ AUTH_RATE_LIMIT_MAX: '3' });
  t.after(s.close);
  const body = { email: 'rl@example.com', password: 'whatever-pass' };
  const statuses = [];
  for (let i = 0; i < 5; i++) statuses.push((await s.call('POST', '/auth/login', { body })).status);
  assert.deepEqual(statuses, [401, 401, 401, 429, 429]);
});

test('metrics endpoint exposes request counters and honours token', async (t) => {
  const s = await startServer({ METRICS_TOKEN: 'm-token' });
  t.after(s.close);
  await s.call('GET', '/version');
  assert.equal((await s.call('GET', '/metrics')).status, 401);
  const m = await s.call('GET', '/metrics', { token: 'm-token' });
  assert.equal(m.status, 200);
  assert.match(m.text, /http_requests_total\{method="GET",route="\/version",status="200"\} 1/);
  assert.match(m.text, /http_request_duration_seconds_bucket/);
});
