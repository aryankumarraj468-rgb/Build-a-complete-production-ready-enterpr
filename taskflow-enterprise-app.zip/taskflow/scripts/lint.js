'use strict';
// Zero-dependency lint: syntax check + a few hygiene rules. Swap for ESLint if desired.
const { execFileSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const files = [];
(function walk(d) {
  for (const e of fs.readdirSync(d, { withFileTypes: true })) {
    if (e.name === 'node_modules' || e.name.startsWith('.')) continue;
    const p = path.join(d, e.name);
    if (e.isDirectory()) walk(p);
    else if (p.endsWith('.js')) files.push(p);
  }
})('.');

let problems = 0;
for (const f of files) {
  try { execFileSync(process.execPath, ['--check', f], { stdio: 'pipe' }); }
  catch (e) { console.error(`SYNTAX ${f}\n${e.stderr}`); problems++; }
  const src = fs.readFileSync(f, 'utf8');
  src.split('\n').forEach((line, i) => {
    if (/\bdebugger\b/.test(line) || /\.only\(/.test(line)) { console.error(`${f}:${i + 1} forbidden: ${line.trim()}`); problems++; }
    if (/\s+$/.test(line)) { console.error(`${f}:${i + 1} trailing whitespace`); problems++; }
  });
  if (!f.startsWith('scripts') && !src.startsWith("'use strict';")) { console.error(`${f}: missing 'use strict'`); problems++; }
}
console.log(`Linted ${files.length} files, ${problems} problem(s)`);
process.exit(problems ? 1 : 0);
