#!/bin/sh
# Post-deploy smoke test. Usage: BASE_URL=https://staging.example.com sh scripts/smoke.sh
set -eu
BASE_URL="${BASE_URL:-http://localhost:3000}"
fail() { echo "SMOKE FAIL: $1" >&2; exit 1; }
code() { curl -s -o /dev/null -w '%{http_code}' --max-time 10 "$@"; }

[ "$(code "$BASE_URL/health/live")" = 200 ]  || fail "liveness"
[ "$(code "$BASE_URL/health/ready")" = 200 ] || fail "readiness"
[ "$(code "$BASE_URL/tasks")" = 401 ]        || fail "auth should be enforced"
curl -s --max-time 10 "$BASE_URL/version" | grep -q '"version"' || fail "version endpoint"
if [ -n "${EXPECT_VERSION:-}" ]; then
  curl -s --max-time 10 "$BASE_URL/version" | grep -q "$EXPECT_VERSION" || fail "expected version $EXPECT_VERSION"
fi
echo "Smoke tests passed against $BASE_URL"
