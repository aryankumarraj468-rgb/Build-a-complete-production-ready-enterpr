# TaskFlow API — Enterprise Reference Application

A production-grade task-management REST API that demonstrates professional engineering practices end to end:
secure application design, automated testing, a gated CI/CD pipeline, containerisation, Kubernetes deployment
(any cloud: EKS / GKE / AKS), and built-in observability.

**Design choice:** the service has **zero runtime dependencies** (Node.js built-ins only). That minimises the
supply-chain attack surface, makes images tiny, and keeps `npm audit` trivially clean.

## Quick start

```bash
npm test                  # 17 tests
npm run test:coverage     # enforces >= 80% line coverage (currently ~99%)
npm run lint
npm start                 # http://localhost:3000

docker compose up --build # API + Prometheus (:9090) + Grafana (:3001)
```

```bash
curl -X POST localhost:3000/auth/register -H 'content-type: application/json' \
     -d '{"email":"me@example.com","password":"a-long-passphrase"}'
TOKEN=$(curl -s -X POST localhost:3000/auth/login -H 'content-type: application/json' \
     -d '{"email":"me@example.com","password":"a-long-passphrase"}' | node -pe 'JSON.parse(require("fs").readFileSync(0)).token')
curl -X POST localhost:3000/tasks -H "authorization: Bearer $TOKEN" -H 'content-type: application/json' \
     -d '{"title":"Ship v1","priority":"high"}'
```

Full contract: [`docs/openapi.yaml`](docs/openapi.yaml).

## What's inside

| Area | Implementation |
|---|---|
| API | Auth (register/login, JWT HS256, scrypt hashing), task CRUD, filtering, pagination, RBAC (user/admin), per-user data isolation |
| Security | Input validation, body-size limit, rate limiting (stricter on auth), security headers, timing-safe comparisons, uniform login timing, non-root read-only container, secrets via env only, 404-not-403 to avoid ID enumeration |
| Reliability | Liveness/readiness/startup probes, graceful shutdown with connection draining, rolling updates with `maxUnavailable: 0`, PDB, HPA, topology spread |
| Observability | Structured JSON logs with request IDs, Prometheus metrics (RED), Grafana dashboard, SLO alerts with runbook links |
| Testing | Unit + integration tests (`node:test`), coverage gate, tests re-run inside Docker build, post-deploy smoke test |
| CI | Lint, Kubernetes schema validation, Dockerfile lint, matrix tests (Node 20/22), CodeQL, secret scan, Trivy config + image scan |
| CD | Immutable SHA-tagged images, SBOM + provenance attestation, auto-deploy to staging, **approval-gated** production, attestation verified before deploy, automatic rollback |

## Pipeline

```
PR / push ─► lint ─┐
             test ─┼─► build (test stage → image → Trivy scan → push GHCR + SBOM + attestation)
         security ─┘                              │
                                                  ▼ (main)
                                  deploy-staging ─► rollout status ─► smoke test ─► (auto rollback on failure)
                                                  │
                      manual dispatch w/ image tag ▼ (requires environment approval)
                                  deploy-production ─► verify attestation ─► rollout ─► smoke ─► (auto rollback)
```

## Deploying to a cloud cluster

1. Create a cluster (EKS/GKE/AKS) with ingress-nginx, cert-manager and (optionally) kube-prometheus-stack.
2. Replace `your-org` / `api.example.com` placeholders (`k8s/overlays/*`, `Dockerfile`, `CODEOWNERS`).
3. Create the `taskflow-secrets` Secret in each namespace (see `k8s/secret.example.yaml`).
4. In GitHub: create **staging** and **production** environments (add required reviewers on production);
   add secret `KUBE_CONFIG_B64` per environment (base64 kubeconfig of a namespace-scoped deployer account, or
   switch to OIDC federation) and variables `STAGING_URL`, `PRODUCTION_URL`.
5. Merge to `main` → CI → staging deploys automatically. Promote with **Actions → CD → Run workflow** and the image tag.

## Configuration

See `.env.example`. In production `JWT_SECRET` (≥ 32 chars) is mandatory and the process refuses to start without it.

## Known limitations / next steps

- Storage is in-memory so each replica holds its own data. For real persistence implement the same
  interface as `src/store.js` on PostgreSQL (ADR-002) — the rest of the app is unchanged. Until then run a single
  replica or accept per-pod state.
- Rate limiting is per pod; enforce globally at the ingress or with Redis.
- Add distributed tracing (OpenTelemetry) and centralised log shipping per your platform standards.
