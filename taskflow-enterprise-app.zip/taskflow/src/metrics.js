'use strict';

const BUCKETS = [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5];
const esc = (v) => String(v).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n');
const labelStr = (l) => {
  const k = Object.keys(l);
  return k.length ? `{${k.map((x) => `${x}="${esc(l[x])}"`).join(',')}}` : '';
};

/** Dependency-free Prometheus registry (counter, gauge, histogram). */
function createMetrics() {
  const counters = new Map();
  const histograms = new Map();
  const gauges = new Map();
  const startedAt = Date.now();
  const key = (name, labels) => name + labelStr(labels);

  return {
    inc(name, labels = {}, by = 1) {
      const k = key(name, labels);
      const c = counters.get(k) || { name, labels, value: 0 };
      c.value += by;
      counters.set(k, c);
    },
    observe(name, labels, seconds) {
      const k = key(name, labels);
      const h = histograms.get(k) || { name, labels, counts: BUCKETS.map(() => 0), sum: 0, count: 0 };
      BUCKETS.forEach((b, i) => { if (seconds <= b) h.counts[i] += 1; });
      h.sum += seconds;
      h.count += 1;
      histograms.set(k, h);
    },
    gauge(name, fn) { gauges.set(name, fn); },
    render() {
      const lines = [];
      const seen = new Set();
      const head = (name, type) => {
        if (seen.has(name)) return;
        seen.add(name);
        lines.push(`# HELP ${name} ${name.replace(/_/g, ' ')}`, `# TYPE ${name} ${type}`);
      };
      for (const c of counters.values()) {
        head(c.name, 'counter');
        lines.push(`${c.name}${labelStr(c.labels)} ${c.value}`);
      }
      for (const h of histograms.values()) {
        head(h.name, 'histogram');
        BUCKETS.forEach((b, i) => lines.push(`${h.name}_bucket${labelStr({ ...h.labels, le: b })} ${h.counts[i]}`));
        lines.push(`${h.name}_bucket${labelStr({ ...h.labels, le: '+Inf' })} ${h.count}`);
        lines.push(`${h.name}_sum${labelStr(h.labels)} ${h.sum}`, `${h.name}_count${labelStr(h.labels)} ${h.count}`);
      }
      for (const [name, fn] of gauges) {
        head(name, 'gauge');
        lines.push(`${name} ${fn()}`);
      }
      head('process_uptime_seconds', 'gauge');
      lines.push(`process_uptime_seconds ${(Date.now() - startedAt) / 1000}`);
      head('process_resident_memory_bytes', 'gauge');
      lines.push(`process_resident_memory_bytes ${process.memoryUsage().rss}`);
      return lines.join('\n') + '\n';
    },
  };
}

module.exports = { createMetrics };
