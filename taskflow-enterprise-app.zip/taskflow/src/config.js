'use strict';

/** Loads and validates configuration from environment variables (12-factor). */
function loadConfig(env = process.env) {
  const nodeEnv = env.NODE_ENV || 'development';
  const isProd = nodeEnv === 'production';
  const int = (v, d) => (v === undefined || v === '' ? d : parseInt(v, 10));

  const jwtSecret = env.JWT_SECRET || (isProd ? null : 'dev-only-secret-change-me');
  if (!jwtSecret) throw new Error('JWT_SECRET is required in production');
  if (isProd && jwtSecret.length < 32) throw new Error('JWT_SECRET must be at least 32 characters in production');

  return Object.freeze({
    env: nodeEnv,
    port: int(env.PORT, 3000),
    version: env.APP_VERSION || require('../package.json').version,
    commit: env.GIT_COMMIT || 'unknown',
    logLevel: env.LOG_LEVEL || (nodeEnv === 'test' ? 'silent' : 'info'),
    jwtSecret,
    jwtTtlSeconds: int(env.JWT_TTL_SECONDS, 3600),
    metricsToken: env.METRICS_TOKEN || null,
    maxBodyBytes: int(env.MAX_BODY_BYTES, 100 * 1024),
    shutdownTimeoutMs: int(env.SHUTDOWN_TIMEOUT_MS, 10000),
    rateLimit: { windowMs: int(env.RATE_LIMIT_WINDOW_MS, 60000), max: int(env.RATE_LIMIT_MAX, 300) },
    authRateLimit: { windowMs: 60000, max: int(env.AUTH_RATE_LIMIT_MAX, 10) },
    admin: { email: env.ADMIN_EMAIL || null, password: env.ADMIN_PASSWORD || null },
  });
}

module.exports = { loadConfig };
