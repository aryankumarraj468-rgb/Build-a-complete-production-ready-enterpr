'use strict';

const crypto = require('node:crypto');
const { HttpError } = require('./errors');
const { hashPassword, verifyPassword, signJwt, verifyJwt } = require('./auth');
const { createRateLimiter } = require('./ratelimit');
const { validateCredentials, validateTask, validatePagination } = require('./validate');

const SECURITY_HEADERS = {
  'x-content-type-options': 'nosniff',
  'x-frame-options': 'DENY',
  'referrer-policy': 'no-referrer',
  'content-security-policy': "default-src 'none'; frame-ancestors 'none'",
  'cache-control': 'no-store',
};

const publicUser = (u) => ({ id: u.id, email: u.email, role: u.role, createdAt: u.createdAt });

/** Builds the HTTP request handler. All dependencies are injected for testability. */
function createApp({ config, store, logger, metrics }) {
  const limiter = createRateLimiter(config.rateLimit);
  const authLimiter = createRateLimiter(config.authRateLimit);
  const routes = [];
  let draining = false;

  const route = (method, path, opts, handler) => {
    const pattern = new RegExp('^' + path.replace(/:(\w+)/g, '([^/]+)') + '$');
    const names = [...path.matchAll(/:(\w+)/g)].map((m) => m[1]);
    routes.push({ method, path, pattern, names, handler, ...opts });
  };

  const authenticate = (req) => {
    const h = req.headers.authorization || '';
    if (!h.startsWith('Bearer ')) throw new HttpError(401, 'unauthorized', 'Missing bearer token');
    const p = verifyJwt(h.slice(7), config.jwtSecret);
    return { id: p.sub, email: p.email, role: p.role };
  };

  const loadOwnedTask = async (id, user) => {
    const task = await store.getTask(id);
    // Return 404 (not 403) to avoid leaking the existence of other users' tasks.
    if (!task || (user.role !== 'admin' && task.ownerId !== user.id)) throw new HttpError(404, 'not_found', 'Task not found');
    return task;
  };

  // ---- Operational endpoints ----
  route('GET', '/health/live', {}, async () => ({ status: 200, body: { status: 'ok' } }));
  route('GET', '/health/ready', {}, async () => {
    if (draining) throw new HttpError(503, 'draining', 'Shutting down');
    await store.ping();
    return { status: 200, body: { status: 'ready' } };
  });
  route('GET', '/version', {}, async () => ({ status: 200, body: { version: config.version, commit: config.commit, env: config.env } }));
  route('GET', '/metrics', { raw: true }, async ({ req }) => {
    if (config.metricsToken && req.headers.authorization !== `Bearer ${config.metricsToken}`) throw new HttpError(401, 'unauthorized', 'Invalid metrics token');
    return { status: 200, text: metrics.render(), contentType: 'text/plain; version=0.0.4' };
  });

  // ---- Auth ----
  route('POST', '/auth/register', { auth: 'strict' }, async ({ body }) => {
    const { email, password } = validateCredentials(body, { strictPassword: true });
    if (await store.findUserByEmail(email)) throw new HttpError(409, 'conflict', 'Email already registered');
    const user = await store.createUser({ email, passwordHash: hashPassword(password) });
    metrics.inc('users_registered_total');
    return { status: 201, body: publicUser(user) };
  });
  route('POST', '/auth/login', { auth: 'strict' }, async ({ body }) => {
    const { email, password } = validateCredentials(body, { strictPassword: false });
    const user = await store.findUserByEmail(email);
    // Always run a hash verification to keep timing uniform for unknown users.
    const ok = verifyPassword(password, user ? user.passwordHash : DUMMY_HASH);
    if (!user || !ok) {
      metrics.inc('login_failures_total');
      throw new HttpError(401, 'invalid_credentials', 'Invalid email or password');
    }
    const token = signJwt({ sub: user.id, email: user.email, role: user.role }, config.jwtSecret, config.jwtTtlSeconds);
    return { status: 200, body: { token, tokenType: 'Bearer', expiresIn: config.jwtTtlSeconds } };
  });

  // ---- Tasks ----
  route('POST', '/tasks', { auth: true }, async ({ body, user }) => {
    const data = validateTask(body, { partial: false });
    const task = await store.createTask({ ...data, ownerId: user.id });
    metrics.inc('tasks_created_total');
    return { status: 201, body: task };
  });
  route('GET', '/tasks', { auth: true }, async ({ query, user }) => {
    const { limit, offset, status } = validatePagination(query);
    const result = await store.listTasks({ ownerId: user.role === 'admin' ? null : user.id, status, limit, offset });
    return { status: 200, body: { ...result, limit, offset } };
  });
  route('GET', '/tasks/:id', { auth: true }, async ({ params, user }) => ({ status: 200, body: await loadOwnedTask(params.id, user) }));
  route('PUT', '/tasks/:id', { auth: true }, async ({ params, body, user }) => {
    await loadOwnedTask(params.id, user);
    const patch = validateTask(body, { partial: true });
    return { status: 200, body: await store.updateTask(params.id, patch) };
  });
  route('DELETE', '/tasks/:id', { auth: true }, async ({ params, user }) => {
    await loadOwnedTask(params.id, user);
    await store.deleteTask(params.id);
    return { status: 204 };
  });

  let taskCount = 0;
  metrics.gauge('tasks_current', () => taskCount);
  const refreshGauges = async () => { taskCount = await store.countTasks(); };

  const DUMMY_HASH = hashPassword(crypto.randomBytes(8).toString('hex'));

  async function readBody(req) {
    const chunks = [];
    let size = 0;
    for await (const c of req) {
      size += c.length;
      if (size > config.maxBodyBytes) throw new HttpError(413, 'payload_too_large', 'Request body too large');
      chunks.push(c);
    }
    if (!size) return undefined;
    if (!(req.headers['content-type'] || '').includes('application/json')) throw new HttpError(415, 'unsupported_media_type', 'Content-Type must be application/json');
    try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw new HttpError(400, 'invalid_json', 'Malformed JSON body'); }
  }

  async function handler(req, res) {
    const startedAt = process.hrtime.bigint();
    const requestId = /^[\w-]{8,64}$/.test(req.headers['x-request-id'] || '') ? req.headers['x-request-id'] : crypto.randomUUID();
    const log = logger.child({ requestId });
    let routeLabel = 'unmatched';
    let userId;

    res.setHeader('x-request-id', requestId);
    for (const [k, v] of Object.entries(SECURITY_HEADERS)) res.setHeader(k, v);

    res.on('finish', () => {
      const seconds = Number(process.hrtime.bigint() - startedAt) / 1e9;
      const labels = { method: req.method, route: routeLabel, status: res.statusCode };
      metrics.inc('http_requests_total', labels);
      metrics.observe('http_request_duration_seconds', { method: req.method, route: routeLabel }, seconds);
      if (routeLabel !== '/health/live' && routeLabel !== '/metrics') {
        log.info('request', { method: req.method, route: routeLabel, status: res.statusCode, durationMs: +(seconds * 1000).toFixed(2), userId });
      }
    });

    try {
      const url = new URL(req.url, 'http://localhost');
      let match = null;
      for (const r of routes) {
        if (r.method !== req.method) continue;
        const m = r.pattern.exec(url.pathname);
        if (m) { match = { r, params: Object.fromEntries(r.names.map((n, i) => [n, decodeURIComponent(m[i + 1])])) }; break; }
      }
      if (!match) throw new HttpError(404, 'not_found', 'Route not found');
      routeLabel = match.r.path;

      const ip = req.socket.remoteAddress || 'unknown';
      if (match.r.auth && !routeLabel.startsWith('/health')) {
        const rl = (match.r.auth === 'strict' ? authLimiter : limiter).check(`${match.r.auth === 'strict' ? 'a' : 'g'}:${ip}`);
        if (!rl.allowed) {
          res.setHeader('retry-after', String(rl.retryAfter));
          throw new HttpError(429, 'rate_limited', 'Too many requests');
        }
      }

      const user = match.r.auth === true ? authenticate(req) : undefined;
      userId = user && user.id;
      const body = ['POST', 'PUT', 'PATCH'].includes(req.method) ? await readBody(req) : undefined;
      const result = await match.r.handler({ req, params: match.params, query: url.searchParams, body, user });

      if (result.text !== undefined) {
        res.writeHead(result.status, { 'content-type': result.contentType });
        res.end(result.text);
      } else if (result.body === undefined) {
        res.writeHead(result.status);
        res.end();
      } else {
        res.writeHead(result.status, { 'content-type': 'application/json' });
        res.end(JSON.stringify(result.body));
      }
    } catch (err) {
      const known = err instanceof HttpError;
      if (!known) log.error('unhandled_error', { error: err.message, stack: err.stack });
      const status = known ? err.status : 500;
      res.writeHead(status, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ error: { code: known ? err.code : 'internal_error', message: known ? err.message : 'Internal server error', details: known ? err.details : undefined, requestId } }));
    }
  }

  return { handler, setDraining: (v) => { draining = v; }, refreshGauges };
}

module.exports = { createApp };
