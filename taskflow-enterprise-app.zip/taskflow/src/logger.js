'use strict';

const LEVELS = { debug: 10, info: 20, warn: 30, error: 40, silent: 100 };

/** Minimal structured JSON logger (one JSON object per line, ready for Loki/ELK/CloudWatch). */
function createLogger(level = 'info', base = {}, out = process.stdout) {
  const threshold = LEVELS[level] ?? LEVELS.info;
  const log = (lvl, msg, fields) => {
    if (LEVELS[lvl] < threshold) return;
    out.write(JSON.stringify({ time: new Date().toISOString(), level: lvl, msg, ...base, ...fields }) + '\n');
  };
  return {
    debug: (m, f) => log('debug', m, f),
    info: (m, f) => log('info', m, f),
    warn: (m, f) => log('warn', m, f),
    error: (m, f) => log('error', m, f),
    child: (extra) => createLogger(level, { ...base, ...extra }, out),
  };
}

module.exports = { createLogger };
