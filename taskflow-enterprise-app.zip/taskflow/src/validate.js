'use strict';

const { HttpError } = require('./errors');

const STATUSES = ['todo', 'in_progress', 'done'];
const PRIORITIES = ['low', 'medium', 'high'];
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function fail(errors) {
  throw new HttpError(400, 'validation_error', 'Request validation failed', errors);
}

function validateCredentials(b, { strictPassword }) {
  if (b === null || typeof b !== 'object' || Array.isArray(b)) fail([{ field: 'body', message: 'must be a JSON object' }]);
  const errors = [];
  if (typeof b.email !== 'string' || !EMAIL_RE.test(b.email) || b.email.length > 254) errors.push({ field: 'email', message: 'must be a valid email' });
  if (typeof b.password !== 'string' || b.password.length > 128) errors.push({ field: 'password', message: 'is required' });
  else if (strictPassword && b.password.length < 10) errors.push({ field: 'password', message: 'must be at least 10 characters' });
  if (errors.length) fail(errors);
  return { email: b.email.trim().toLowerCase(), password: b.password };
}

function validateTask(b, { partial }) {
  if (b === null || typeof b !== 'object' || Array.isArray(b)) fail([{ field: 'body', message: 'must be a JSON object' }]);
  const errors = [];
  const out = {};
  const has = (k) => b[k] !== undefined;

  if (has('title') || !partial) {
    if (typeof b.title !== 'string' || !b.title.trim() || b.title.length > 120) errors.push({ field: 'title', message: 'must be a non-empty string up to 120 chars' });
    else out.title = b.title.trim();
  }
  if (has('description')) {
    if (typeof b.description !== 'string' || b.description.length > 2000) errors.push({ field: 'description', message: 'must be a string up to 2000 chars' });
    else out.description = b.description;
  }
  if (has('status')) {
    if (!STATUSES.includes(b.status)) errors.push({ field: 'status', message: `must be one of ${STATUSES.join(', ')}` });
    else out.status = b.status;
  }
  if (has('priority')) {
    if (!PRIORITIES.includes(b.priority)) errors.push({ field: 'priority', message: `must be one of ${PRIORITIES.join(', ')}` });
    else out.priority = b.priority;
  }
  if (has('dueDate')) {
    if (b.dueDate !== null && (typeof b.dueDate !== 'string' || Number.isNaN(Date.parse(b.dueDate)))) errors.push({ field: 'dueDate', message: 'must be an ISO-8601 date or null' });
    else out.dueDate = b.dueDate;
  }
  if (errors.length) fail(errors);
  return out;
}

function validatePagination(query) {
  const limit = query.get('limit') === null ? 20 : Number(query.get('limit'));
  const offset = query.get('offset') === null ? 0 : Number(query.get('offset'));
  if (!Number.isInteger(limit) || limit < 1 || limit > 100) fail([{ field: 'limit', message: 'must be an integer 1-100' }]);
  if (!Number.isInteger(offset) || offset < 0) fail([{ field: 'offset', message: 'must be an integer >= 0' }]);
  const status = query.get('status');
  if (status !== null && !STATUSES.includes(status)) fail([{ field: 'status', message: `must be one of ${STATUSES.join(', ')}` }]);
  return { limit, offset, status };
}

module.exports = { validateCredentials, validateTask, validatePagination, STATUSES, PRIORITIES };
