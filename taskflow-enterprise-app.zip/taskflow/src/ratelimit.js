'use strict';

/** Fixed-window in-memory rate limiter. For multi-replica setups also enforce at the ingress, or swap in Redis. */
function createRateLimiter({ windowMs, max }, now = () => Date.now()) {
  const hits = new Map();
  return {
    check(key) {
      const t = now();
      let e = hits.get(key);
      if (!e || e.resetAt <= t) {
        e = { count: 0, resetAt: t + windowMs };
        hits.set(key, e);
        if (hits.size > 10000) for (const [k, v] of hits) if (v.resetAt <= t) hits.delete(k);
      }
      e.count += 1;
      return { allowed: e.count <= max, remaining: Math.max(0, max - e.count), retryAfter: Math.ceil((e.resetAt - t) / 1000) };
    },
  };
}

module.exports = { createRateLimiter };
