'use strict';

const http = require('node:http');
const { loadConfig } = require('./config');
const { createLogger } = require('./logger');
const { createMetrics } = require('./metrics');
const { createMemoryStore } = require('./store');
const { createApp } = require('./app');
const { hashPassword } = require('./auth');

async function main() {
  const config = loadConfig();
  const logger = createLogger(config.logLevel, { service: 'taskflow-api', version: config.version });
  const metrics = createMetrics();
  const store = createMemoryStore();

  if (config.admin.email && config.admin.password) {
    await store.createUser({ email: config.admin.email.toLowerCase(), passwordHash: hashPassword(config.admin.password), role: 'admin' });
    logger.info('admin_seeded', { email: config.admin.email });
  }

  const app = createApp({ config, store, logger, metrics });
  const server = http.createServer(app.handler);
  server.keepAliveTimeout = 65000; // > typical load balancer idle timeout (60s)
  server.headersTimeout = 66000;
  server.requestTimeout = 30000;

  const gaugeTimer = setInterval(() => app.refreshGauges().catch(() => {}), 15000);
  gaugeTimer.unref();

  server.listen(config.port, () => logger.info('server_started', { port: config.port, env: config.env }));

  let shuttingDown = false;
  const shutdown = (signal) => {
    if (shuttingDown) return;
    shuttingDown = true;
    logger.info('shutdown_initiated', { signal });
    app.setDraining(true); // readiness fails immediately so the LB stops sending traffic
    setTimeout(() => {
      server.close(() => { logger.info('shutdown_complete'); process.exit(0); });
      server.closeIdleConnections();
    }, 5000);
    setTimeout(() => { logger.error('shutdown_forced'); process.exit(1); }, config.shutdownTimeoutMs + 5000).unref();
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('unhandledRejection', (e) => { logger.error('unhandled_rejection', { error: String(e) }); });
  process.on('uncaughtException', (e) => { logger.error('uncaught_exception', { error: e.message, stack: e.stack }); process.exit(1); });
}

main().catch((e) => { console.error(e); process.exit(1); });
