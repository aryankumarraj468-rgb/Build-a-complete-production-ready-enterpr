'use strict';

const crypto = require('node:crypto');
const { HttpError } = require('./errors');

const b64u = (b) => Buffer.from(b).toString('base64url');

/** scrypt password hashing with per-user random salt. Format: salt:hash (hex). */
function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, 64);
  return `${salt.toString('hex')}:${hash.toString('hex')}`;
}

function verifyPassword(password, stored) {
  const [saltHex, hashHex] = String(stored).split(':');
  if (!saltHex || !hashHex) return false;
  const expected = Buffer.from(hashHex, 'hex');
  const actual = crypto.scryptSync(password, Buffer.from(saltHex, 'hex'), expected.length);
  return crypto.timingSafeEqual(actual, expected);
}

/** HS256 JWT. */
function signJwt(payload, secret, ttlSeconds, now = Date.now()) {
  const iat = Math.floor(now / 1000);
  const body = { ...payload, iat, exp: iat + ttlSeconds };
  const data = `${b64u(JSON.stringify({ alg: 'HS256', typ: 'JWT' }))}.${b64u(JSON.stringify(body))}`;
  const sig = crypto.createHmac('sha256', secret).update(data).digest('base64url');
  return `${data}.${sig}`;
}

function verifyJwt(token, secret, now = Date.now()) {
  const parts = String(token).split('.');
  if (parts.length !== 3) throw new HttpError(401, 'invalid_token', 'Malformed token');
  const [h, p, s] = parts;
  let header, payload;
  try {
    header = JSON.parse(Buffer.from(h, 'base64url').toString());
    payload = JSON.parse(Buffer.from(p, 'base64url').toString());
  } catch {
    throw new HttpError(401, 'invalid_token', 'Malformed token');
  }
  if (header.alg !== 'HS256') throw new HttpError(401, 'invalid_token', 'Unsupported algorithm');
  const expected = crypto.createHmac('sha256', secret).update(`${h}.${p}`).digest();
  const given = Buffer.from(s, 'base64url');
  if (given.length !== expected.length || !crypto.timingSafeEqual(given, expected)) {
    throw new HttpError(401, 'invalid_token', 'Invalid signature');
  }
  if (typeof payload.exp !== 'number' || payload.exp <= Math.floor(now / 1000)) {
    throw new HttpError(401, 'token_expired', 'Token expired');
  }
  return payload;
}

module.exports = { hashPassword, verifyPassword, signJwt, verifyJwt };
