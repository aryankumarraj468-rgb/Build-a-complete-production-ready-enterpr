'use strict';

const crypto = require('node:crypto');

/**
 * In-memory repository. The async interface mirrors what a PostgreSQL implementation would expose,
 * so it can be swapped without touching the app layer (docs/ARCHITECTURE.md, ADR-002).
 */
function createMemoryStore() {
  const users = new Map();
  const emailIndex = new Map();
  const tasks = new Map();

  return {
    async ping() { return true; },
    async createUser({ email, passwordHash, role = 'user' }) {
      const user = { id: crypto.randomUUID(), email, passwordHash, role, createdAt: new Date().toISOString() };
      users.set(user.id, user);
      emailIndex.set(email, user.id);
      return user;
    },
    async findUserByEmail(email) { return users.get(emailIndex.get(email)) || null; },
    async createTask(data) {
      const now = new Date().toISOString();
      const task = { id: crypto.randomUUID(), description: '', status: 'todo', priority: 'medium', dueDate: null, ...data, createdAt: now, updatedAt: now };
      tasks.set(task.id, task);
      return task;
    },
    async getTask(id) { return tasks.get(id) || null; },
    async listTasks({ ownerId, status, limit, offset }) {
      const items = [...tasks.values()].filter((t) => (!ownerId || t.ownerId === ownerId) && (!status || t.status === status));
      items.sort((a, b) => b.createdAt.localeCompare(a.createdAt) || a.id.localeCompare(b.id));
      return { total: items.length, items: items.slice(offset, offset + limit) };
    },
    async updateTask(id, patch) {
      const t = tasks.get(id);
      if (!t) return null;
      Object.assign(t, patch, { updatedAt: new Date().toISOString() });
      return t;
    },
    async deleteTask(id) { return tasks.delete(id); },
    async countTasks() { return tasks.size; },
  };
}

module.exports = { createMemoryStore };
